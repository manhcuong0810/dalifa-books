'use client';
import { useEffect, useState, use } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';

export default function NewsPage({ searchParams }: { searchParams: Promise<any> }) {
  const [articles, setArticles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const params = use(searchParams);
  
  const category = params.cat || 'Tất cả';

  useEffect(() => {
    api('articles').then(data => {
      setArticles(data);
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="empty animate-fade">Đang tải dữ liệu...</div>;

  const filtered = category === 'Tất cả' ? articles : articles.filter(a => a.category === category);

  return (
    <div className="animate-fade" style={{ maxWidth: 1200, margin: '4rem auto', padding: '0 2rem' }}>
      <div className="section-title">
        <h2>{category === 'Tất cả' ? 'Tin tức & Sự kiện' : category}</h2>
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', gap: '2rem' }}>
        {filtered.map(a => (
          <div key={a.id} style={{ padding: '2rem', background: '#f9f9f9', borderRadius: '16px' }}>
            <span style={{ color: 'var(--accent)', fontWeight: 'bold' }}>{a.category}</span>
            <h3 style={{ margin: '1rem 0' }}>{a.title}</h3>
            <p style={{ color: '#666' }}>{a.summary}</p>
            <Link href={'/tin-tuc/' + a.slug} style={{ display: 'inline-block', marginTop: '1rem', color: 'var(--green)', fontWeight: 'bold' }}>Đọc tiếp →</Link>
          </div>
        ))}
      </div>
      {!filtered.length && <div className="empty">Không có bài viết nào.</div>}
    </div>
  );
}
