export default function ContactPage() {
  return (
    <div className="animate-fade" style={{ maxWidth: 800, margin: '4rem auto', padding: '0 2rem' }}>
      <h1>Liên hệ với Dalifa Books</h1>
      <form style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '2rem' }}>
        <input placeholder="Họ và tên" style={{ padding: '1rem', borderRadius: '8px', border: '1px solid #ccc' }} />
        <input placeholder="Email" style={{ padding: '1rem', borderRadius: '8px', border: '1px solid #ccc' }} />
        <textarea placeholder="Nội dung" rows={5} style={{ padding: '1rem', borderRadius: '8px', border: '1px solid #ccc' }}></textarea>
        <button type="button" className="button" style={{ alignSelf: 'flex-start' }}>Gửi tin nhắn</button>
      </form>
    </div>
  );
}
